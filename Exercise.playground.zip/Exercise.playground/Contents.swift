//: Playground - noun: a place where people can play

import UIKit

class Dog: CustomStringConvertible {
    let imie: String
    let gatunek: String
    let image: UIImage?
    let wiek: Int
    
    init (name: String, breed: String, age: Int){
        self.imie = name
        self.gatunek = breed
        self.wiek = age
        self.image = UIImage(named: "")
    }
        var description: String {
        var description = ""
        description += "\(self.imie) - "
        description += "\(self.gatunek) - "
        description += "\(self.wiek) -"
        if (self.image == nil){
            description += " Nie posiada zdjęcia"
        } else {
            description += "Posiada zdjęcie"
        }
        
        return description
    }
}

let pierwszyPies = Dog(name: "Nelson", breed: "Cocker Spaniel", age: 7)
print(pierwszyPies)